from __future__ import division
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.stats.proportion import proportions_ztest
import scipy.stats
import math


"""
This code is divided into two parts:
-Part 1 contains several functions to print descriptive statistics and produce some visualizations
of data in individual columns or of the dataframe itself. Each feature's relationship to survival rate
is explored.

-Part 2 builds a new dataset containing information relevant to each of 35 different demographics (mixed attributes),
conducts statistical tests on each demographic, builds confidence intervals for the survival rate
of each demographic, etc. A function is also defined to conduct statistical tests between two specific demographics

At the very end of the document, any of the single column descriptive statistics functions
can be uncommented to run the code and display the output. The dataframe containing the statistical test results
can also be uncommented to display the results. 
There are also several other tables generated which can be viewed by uncommenting printed statements near the end of the document
"""



titanic= pd.read_csv('titanic_data.csv')


#Change the value of adult_age below to redefine the age of adulthood. All following analysis will use this value to define the minimum
#age of adulthood
age_of_adulthood=18

#Adding a column to df that contains a status of 'Adult', 'Child', or NaN. Children are anyone under the defined age of adulthood. 
def adult_status(age, adult_age=age_of_adulthood):
	if age<adult_age:
		return 'Child'
	elif age >=adult_age:
		return 'Adult'
	else:
		return age

titanic['Adult_Status']= titanic['Age'].apply(adult_status)


#Function to print basic info about the dataframe including
#Column Names
#Dataframe Shape
#Proportion of defined (non-nan) values in each column
#Data type of each column
def about_df():
	print 'Column Names'
	print titanic.columns.values
	print

	print 'Dataframe Shape (rows, columns)'
	print titanic.shape
	print
	
	print "Proportion of defined values (not nan)"
	print titanic.count()/len(titanic)
	print
	#(titanic.count()/len(titanic)).to_csv('Missing_Value_Ratios.csv')
	
	#Columns containing string values are assigned the 'object' datatype
	for i in titanic.columns.values:
		print i, titanic[i].dtype
	print
		

		
		
		
#For Categorical data, this will create a frequency table for the number of passengers in each category
def create_distribution_table(col_name, index_names= None, index_sort=False, df= titanic):
	
	x_count= df[col_name].value_counts(normalize=False)
	x_relf= df[col_name].value_counts(normalize=True)
	x_dist= pd.concat([x_count, x_relf], axis=1)
	x_dist.columns= ['Count', 'Relative Frequency']
	if index_sort:
		x_dist.sort_index(inplace=True)
	if index_names is not None:
		x_dist.index= index_names
	return x_dist
		
#Create a dataframe containing the count and relative frequency of whether or not passengers survived
def about_survived():
	survivor_dist= create_distribution_table('Survived', index_names= ['Perished', 'Survived'], index_sort=True)
	print 'Survival Status Distribution'
	print
	print survivor_dist
	print



#Create two subsets of titanic data: one containing only survivors, one containing only non-survivors
survived_df= titanic[titanic['Survived']==1]
perished_df= titanic[titanic['Survived']==0]


#The following 3 functions will describe the age, sex, and class columns. They will also compare these qualities for 
#passengers that have survived vs. passengers that have perished. 

	
#Descriptive statistics about the ages of passengers including:
#Number of passengers with defined ages (non-nan values)
#mean, median, min, max age
#Number of children under 1 year old
#Total number of children (under 18 years old)
#Create histogram of the distribution of defined ages
#Histogram of only children's ages
def about_age():
	print 'Number of passengers with defined aged'
	print titanic['Age'].count()
	print
	
	#Descriptive statistics for defined passenger ages
	defined_ages= titanic['Age'].dropna()
	print 'Descriptive Stats of Defined Ages'
	print defined_ages.describe()
	print
	
	#Number of children under 1 year old
	print 'Number of children under 1 year old'
	print len(defined_ages[defined_ages < 1])
	print
	
	#Total number of children (under 18 years old)
	print 'Total number of children (under the age of adulthood defined in source code)'
	num_children= len(defined_ages[defined_ages < age_of_adulthood])
	print num_children
	print '%s%% of all defined ages' %(round(float(num_children)*(100)/len(defined_ages), 2))
	print 
	
	#Create a histogram of the distribution of defined ages
	plt.hist(defined_ages, bins=16)
	plt.title('Distribution of Defined Ages')
	plt.xlabel('Age')
	plt.ylabel('Number of Passengers')
	plt.show()
	
	#Create a histogram of the distribution of children's ages
	plt.hist(defined_ages[defined_ages<age_of_adulthood], bins=age_of_adulthood-1)
	plt.title('Distribution of Childrens\' Ages')
	plt.xlabel('Age')
	plt.ylabel('Number of Passengers')
	plt.show()
	
	#Create a box plot of ages for survivors and non-survivors
	plt.boxplot([survived_df['Age'].dropna(), perished_df['Age'].dropna()], 0, 'o')
	plt.xticks([1, 2], ['Survivors', 'Non-Survivors'])
	plt.title('Distribution of Ages of Survivors and Non-Survivors')
	plt.ylabel('Age')
	plt.ylim([0,90])
	plt.show()
	
	#Print descriptive stats for survivors ages vs non-survivors ages
	print 'Descriptive Stats of Survivor Ages'
	print survived_df['Age'].describe()
	print
	print 'Descriptive Stats of Non-Survivor Ages'
	print perished_df['Age'].describe()
	print
	return
	
	


#Frequency table of passengers in each class
#Pie chart of percentage of passengers in each class
def about_Pclass():
	pclass_dist=create_distribution_table('Pclass', index_names= ['1st Class', '2nd Class', '3rd Class'], index_sort=True)
	pclass_dist_survivors= create_distribution_table('Pclass', index_names= ['1st Class', '2nd Class', '3rd Class'], index_sort=True, df=survived_df)
	pclass_dist_perished= create_distribution_table('Pclass', index_names= ['1st Class', '2nd Class', '3rd Class'], index_sort=True, df=perished_df)
	print 'Distribution of Passenger Classes'
	print pclass_dist
	print
	#pclass_dist.to_csv('Distribution_of_Classes.csv')
	print 'Distribution of Passenger Classes of Survivors'
	print pclass_dist_survivors
	print
	print 'Distribution of Passenger Classes of Non-Survivors'
	print pclass_dist_perished
	print
	
	
	#Pie Charts for general sample, survivors, and non-survivors
	fig, (ax1, ax2)= plt.subplots(1, 2, figsize= (13, 5))
	labels= '1st Class', '2nd Class', '3rd Class'
	sizes1= list(pclass_dist_survivors['Relative Frequency'])
	sizes2= list(pclass_dist_perished['Relative Frequency'])
	colors= ['yellowgreen', 'mediumpurple', 'lightskyblue']
	
	ax1.pie(sizes1, labels=labels, colors=colors, shadow=True, startangle=70, autopct='%1.1f%%')
	ax1.axis('equal')
	ax2.pie(sizes2, labels=labels, colors=colors, shadow=True, startangle=70, autopct='%1.1f%%')
	ax2.axis('equal')	
	
	ax1.set_title('Survivors', y=1.05, fontsize=20)
	ax2.set_title('Non-Survivors', y=1.05, fontsize=20)
	plt.show()
	return

	
	
	
#Frequency table for each sex
def about_sex():
	sex_dist= create_distribution_table('Sex', index_names= ['Female', 'Male'], index_sort=True)
	sex_dist_survivors= create_distribution_table('Sex', index_names= ['Female', 'Male'], index_sort=True, df= survived_df)
	sex_dist_perished= create_distribution_table('Sex', index_names= ['Female', 'Male'], index_sort=True, df= perished_df)
	print 'Distribution of Sexes of All Passengers'
	print sex_dist
	print
	sex_dist.to_csv('Passenger_Sexes.csv')
	print 'Distribution of Sexes of Survivors'
	print sex_dist_survivors
	print
	print 'Distribution of Sexes of Non-Survivors'
	print sex_dist_perished
	print
	
	#Pie Charts for general sample, survivors, and non-survivors
	fig, (ax1, ax2)= plt.subplots(1, 2, figsize= (13, 5))
	labels= 'Female', 'Male'
	sizes1= list(sex_dist_survivors['Relative Frequency'])
	sizes2= list(sex_dist_perished['Relative Frequency'])
	colors= ['yellowgreen', 'mediumpurple']
	
	ax1.pie(sizes1, labels=labels, colors=colors, shadow=True, startangle=70, autopct='%1.1f%%')
	ax1.axis('equal')
	ax2.pie(sizes2, labels=labels, colors=colors, shadow=True, startangle=70, autopct='%1.1f%%')
	ax2.axis('equal')	
	
	ax1.set_title('Survivors', y=1.05, fontsize=20)
	ax2.set_title('Non-Survivors', y=1.05, fontsize=20)
	plt.show()


#about_df()
#about_survived()
#about_age()
#about_Pclass()
#about_sex()
		

		
		
#__________________PART 2: BUILDING STATISTICAL TEST FOR VARIOUS DEMOGRAPHICS__________________________________________________

#Function to create a subset of titanic data. 
#Sex, class, and/or adult status (adult or child) may be specified	
def titanic_subset(sex='', pclass='', adult_status=''):
	sub_titanic= titanic
	if sex !='':
		sub_titanic= sub_titanic[sub_titanic['Sex']==sex]
	if pclass !='':
		sub_titanic= sub_titanic[sub_titanic['Pclass']==int(pclass)]
	if adult_status !='':
		sub_titanic= sub_titanic[sub_titanic['Adult_Status']==adult_status]
	return sub_titanic

	
#Given a sex, class, and/or adult_status, this will create a subset of 
#all titanic data WITHOUT any of these attributes
#Ex: if sex='male', pclass=2, the returned dataset will contain all data of
#passengers who are not 2nd class males
def remainder_subset(sex='', pclass='', adult_status='', main_set=titanic)	:		
	main_subset= titanic_subset(sex, pclass, adult_status)
	if adult_status!='':
		main_set= main_set.dropna(subset=['Adult_Status'])
	remainder= main_set[~main_set.isin(main_subset)].dropna(subset=['PassengerId'])
	return remainder

#Takes a dataframe as an argument (subset of all passenger data)
#Returns tuple with the survival rate of all passengers in subset (proportion)
#and total number of passengers in the subset
def find_survival_rate(t_subset):
	num_survivors= len(t_subset[t_subset['Survived']==1])
	num_total= len(t_subset)
	if num_total==0:
		return (np.nan, 0)
	survival_rate= float(num_survivors)/num_total
	return (survival_rate, num_total)

	
#Used to reformat strings that will be used as indices when creating 
#a dataframe for each demographic of sex, class, and adult status
#Takes a messy string as an argument
#returns a reformatted string where C=Child, A=Adult, M=Male, F=Female, 1=1st class, etc.
#Ex: CM2 represents male children in 2nd class
#Ex: A3 represents all adults in 3rd class
#Ex: F represents all females
def re_format_strings(s):
	s_list= s.split(' ')
	first_char_list= []
	for i in s_list:
		try:
			first_char_list.append(i[0].upper())
		except Exception:
			pass
	return ''.join(first_char_list)

#Takes a column names as an argument
#Returns a list of unique values in that column
#List also includes a blank string which will serve a purpose as an argument in other functions	
def get_uniques(col_name):
	clean_titanic= titanic.dropna(subset=[col_name])
	unique_values= list(clean_titanic[col_name].unique())
	unique_values.append('')
	return unique_values

#Creation of a new dataframe which will contain every possible combination of adult_status, sex, and class
sub_class_df= pd.DataFrame(columns= ['Levels' ,'Adult_Status', 'Sex', 'Pclass', 'Survival_Rate', 'Sample_Size', 'Population_Estimate', 'Num_Survived', 'Num_Perished', \
'Survival_Rate_of_Rest', 'Sample_Size_of_Rest', 'Num_Survived_Rest', 'Num_Perished_Rest'])

#Populates the sub_class_df dataframe
#3 for loops create every possible combination of adult_status, sex, and class (i, j, k)
#Some columns are intentionally filled with np.nan values and will be filled in later
#Survival rates are calculated for the each demographic
#Survival rates are calculated for all other data NOT contained in the specific demographic
#A count of passengers included in each demographic as well as in the remainder data (sample size, sample size of rest)
#i, j, and k values are used to create the index name along with the reformatting function defined earlier
#When NO attributes are specified, demographic will be equivalent to the entire dataset and indexed as (All Data)
for i in get_uniques('Adult_Status'):
	for j in get_uniques('Sex'):
		for k in get_uniques('Pclass'):
			
			data= {'Levels': np.nan, 'Adult_Status': i, 'Sex': j, 'Pclass': k, 'Survival_Rate': find_survival_rate(titanic_subset(sex=j, pclass=k, adult_status=i))[0] ,\
			'Sample_Size': int(find_survival_rate(titanic_subset(sex=j, pclass=k, adult_status=i))[1]),'Population_Estimate': np.nan, 'Num_Survived': np.nan, 'Num_Perished': np.nan, \
			'Survival_Rate_of_Rest': find_survival_rate(remainder_subset(sex=j, pclass=k, adult_status=i))[0], 'Sample_Size_of_Rest': find_survival_rate(remainder_subset(sex=j, \
			pclass=k, adult_status=i))[1], 'Num_Survived_Rest': np.nan, 'Num_Perished_Rest': np.nan}			
			new_str= ' '.join([str(i), str(j), str(k)])
			if new_str== '  ':
				new_str= 'All Data'
			else:
				new_str= re_format_strings(new_str)
			sub_class_df.loc[new_str]=data

			
#Takes a series as an argument
#Returns an integer (number of levels)
#Number of levels is defined as the number of specified attributes in a given demographic
#Ex: CF1 (child, female, 1st class) is a level 3 demographic
#Ex: A (adult) is a level 1 demographic
#This function will be used to create a 'level' column in the demographic dataframe
def num_levels(s):
	levels=3
	if s['Adult_Status']=='':
		levels-=1
	if s['Pclass']=='':
		levels-=1
	if s['Sex']=='':
		levels-=1
	return levels			

#Sort the demographic dataframe by survival rate of each demographic in decreasing order
#This created a copy of the dataframe which we will use from now on in our analysis
sorted_sub_classes= sub_class_df.sort_values(by='Survival_Rate', ascending=False)


	
#Create Several new calculated columns to use later in statistical analysis
#Levels: Number of attributes specified in given demographic (row)
#Num_Survived: Number of passengers that survived in row's demographic
#Num_Perished: Number of passengers that died in row's demographic
#Num_Survived_Rest: Number of surviving passengers that are NOT contained in row's demographic
#Num_Perished_Rest: Number of perishing passengers that are NOT contained in row's demographic
#
#Population estimate: estimation of the total number of passengers belonging to each demographic in the
#population of all titanic passengers. Note that our original dataset was incomplete (the titanic had 1317 passengers, not 891
#Population estimates will be used later in statistical analysis
sorted_sub_classes['Levels']= sorted_sub_classes.apply(num_levels, axis=1)
sorted_sub_classes= sorted_sub_classes[sorted_sub_classes['Levels']>0]
sorted_sub_classes['Num_Survived']= sorted_sub_classes['Sample_Size'].multiply(sorted_sub_classes['Survival_Rate'])
sorted_sub_classes['Num_Perished']= sorted_sub_classes['Sample_Size']- sorted_sub_classes['Num_Survived']
sorted_sub_classes['Num_Survived_Rest']= sorted_sub_classes['Sample_Size_of_Rest'].multiply(sorted_sub_classes['Survival_Rate_of_Rest'])
sorted_sub_classes['Num_Perished_Rest']= sorted_sub_classes['Sample_Size_of_Rest']- sorted_sub_classes['Num_Survived_Rest']
sorted_sub_classes['Population_Estimate']= (sorted_sub_classes['Sample_Size']*float(1317)/(sorted_sub_classes['Sample_Size']+sorted_sub_classes['Sample_Size_of_Rest'])).round(decimals=0)
#______________________________________________________

"""
A confidence interval will be constructed for each elligible demographic survival proportion point estimate.

In order to do this, we need to check that our sample size is sufficient to assume
normality in the distribution of possible sample proportions. A sample size is sufficient if the number
of survivors, as well the number of perished passengers in the demographic's sample are both at least 10

A confidence interval will be built around the point estimate for each demographic's survival rate

"""

#Function to determine whether normality can be assumed in the distribution of possible sample proportions
#Takes a float and an integer as arguments (proportion of survivors, number of passengers)
#returns a boolean if number of survivors or perishing passengers is less than 10
def normality_assumption_valid(proportion, sample_size):
	cond1= proportion*sample_size >=10
	cond2= (1-proportion)*sample_size >=10
	if cond1 and cond2:
		return True
	else:
		return False

#Tests for validity of normality assumption for each demographic, as well as
#Each remainder of data to which the demographic will be compared.
#Creates a new column in the sorted_sub_classes dataframe which specifies whether normality can be assumed
norm_subs= np.vectorize(normality_assumption_valid)(sorted_sub_classes['Survival_Rate'], sorted_sub_classes['Sample_Size'])
norm_remainders=np.vectorize(normality_assumption_valid)(sorted_sub_classes['Survival_Rate_of_Rest'], sorted_sub_classes['Sample_Size_of_Rest'])
sorted_sub_classes['Normal_Assumption_Valid']= (norm_subs) & (norm_remainders)


#function to estimate half width of confidence interval of finite population
#The finite population correction factor is used in the calculation
def half_c_interval(p, n, N, alpha=.05):
	area= 1-alpha/2
	z= scipy.stats.norm.ppf(area)
	return math.sqrt(p*(1-p)*(N-n)/(n*(N-1)))*z


#Three lists are initialized and will be populated with values to eventually include in the sorted_sub_classes dataframe
#This is done by looping over each row in the dataframe and using its elements to calculate new values
#This approach was taken because vectorization of functions with ndarrays as arguments has proven problematic
#half_interval_list is half the CI width for the point estimate of the population proportion of survivors from that demographic 
half_interval_list=[]
half_interval_rest_list=[]
for index, row in sorted_sub_classes.iterrows():
	try:
		h= half_c_interval(p=row['Survival_Rate'], n=row['Sample_Size'], N=row['Population_Estimate'])
		h_rest= half_c_interval(p= row['Survival_Rate_of_Rest'], n=row['Sample_Size_of_Rest'], N=1317-row['Population_Estimate'])
	except Exception:
		h=np.nan
		h_rest= np.nan
	half_interval_list.append(h)
	half_interval_rest_list.append(h_rest)
	

	
#New columns are created to house the values in each list we created
#The half confidence interval is added and subtracted to create the upper and lower limits, respectively
sorted_sub_classes['Half_Confidence_Interval']= half_interval_list
sorted_sub_classes['Lower_Limit']= sorted_sub_classes['Survival_Rate'].subtract(sorted_sub_classes['Half_Confidence_Interval'])
sorted_sub_classes['Upper_Limit']= sorted_sub_classes['Survival_Rate'].add(sorted_sub_classes['Half_Confidence_Interval'])
sorted_sub_classes['Half_Confidence_Interval_Rest']= half_interval_rest_list

#Some of these demographics failed the normality assumption
#So these values will be replaced with NaNs for demographics that didnt meet the normality standard
row_index=sorted_sub_classes.Normal_Assumption_Valid==False
sorted_sub_classes.loc[row_index, 'Half_Confidence_Interval']=np.nan
sorted_sub_classes.loc[row_index, 'Lower_Limit']=np.nan
sorted_sub_classes.loc[row_index, 'Upper_Limit']=np.nan
sorted_sub_classes.loc[row_index, 'Half_Confidence_Interval_Rest']=np.nan


#Function to make a conclusion about a statistical test
#Takes a float (pvalue) and boolean (normality assumption valid) as arguments
#Decides whether or not to reject null hypothesis that demographic survival rate is equal to that of the remainder of passengers
#Returns 'Test Not Applicable' if normality assumption is invalid
def test_conclusion(p, valid_test=True):
	if valid_test==False:
		return 'Test Not Applicable'
	else:
		if p<.05:
			return 'Reject H0'
		else:
			return 'Do Not Reject H0'

'''While the normality assumption was useful for constructing confidence intervals, 
and identifying some statistically significant differences in survival rates, our sample sizes
were too small for several of the most interesting demographics. Here, we will now conduct a Fisher Exact Test
on each demographic since the Fisher Exact Test does not rely on the normality assumption and can handle
small sample sizes.
'''

#A list of Fisher p-values is initialized
#list is populated by looping over each row in the dataframe and calculating the p value
#variable 'a' is a contingency table containing the number of survivors and perished passengers for 
#1. The demographic of interest, and
#2. All passengers NOT in the demographic of interest
fisher_p_vals= []
for index, row in sorted_sub_classes.iterrows():
	a=  np.array([[row['Num_Survived'], row['Num_Perished']], [row['Num_Survived_Rest'], row['Num_Perished_Rest']]])
	fisher_p_vals.append(scipy.stats.fisher_exact(a, alternative='two-sided')[1])

#A new column is created for the fisher exact test p-values 
#New column is created for the test conclusion using a vectorized version of the test_conclusion function created in this file
sorted_sub_classes['Fisher_Test_p-value']= fisher_p_vals
sorted_sub_classes['Fisher_Test_Conclusion']= np.vectorize(test_conclusion)(p= sorted_sub_classes['Fisher_Test_p-value'])


		
"""
The sorted_sub_classes dataframe compares each demographic's sample proportion
to ALL passengers not contained in that specific demographic.

However, we may want to compare a specific demographic to another demographic
Ex: 1st Class Female Children vs. Other Female Children
Ex: 3rd Class Adults vs. All 2nd Class Passengers
Ex: 2nd Class Male Children vs. All adult women

The function below is designed to perform a Fisher Exact test between two such groups
"""

#Takes 6 different attributes (strings, integers) as arguments
#Returns a series containing the p value and test conclusion of the Fisher Exact Test, 
#as well as survival rates, survivor counts, and perished passenger counts for both groups
#If group 1 demographic and group 2 demographic have any common passengers, they will be included in group one and excluded from group 2
def stat_sig_between_groups(sex1='', pclass1='', adult_status1='', sex2='', pclass2='', adult_status2=''):
	sub_group_df= titanic_subset(sex1, pclass1, adult_status1)
	remainder_group_df= remainder_subset(sex1, pclass1, adult_status1, main_set=titanic_subset(sex2, pclass2, adult_status2))
	
	sub_group_survival= find_survival_rate(sub_group_df)[0]
	sub_group_sample_size= find_survival_rate(sub_group_df)[1]
	sub_group_survivor_count= sub_group_survival*sub_group_sample_size
	sub_group_perished_count= sub_group_sample_size- sub_group_survivor_count
	
	remainder_group_survival= find_survival_rate(remainder_group_df)[0]
	remainder_group_sample_size= find_survival_rate(remainder_group_df)[1]
	remainder_group_survivor_count= remainder_group_survival*remainder_group_sample_size
	remainder_group_perished_count= remainder_group_sample_size- remainder_group_survivor_count
	
	s_data= {'Sub_Group_Survival_Rate': sub_group_survival,'Sub_Group_Survivor_Count': sub_group_survivor_count,'Sub_Group_Perished_Count': sub_group_perished_count,\
	'Remainder_Group_Suvival_Rate': remainder_group_survival,'Remainder_Group_Survivor_Count': remainder_group_survivor_count, \
	'Remainder_Group_Perished_Count': remainder_group_perished_count}
	s= pd.DataFrame(data= s_data, index=['Fisher_Test'])
	
	cont_table= np.array([[sub_group_survivor_count, sub_group_perished_count],[remainder_group_survivor_count, remainder_group_perished_count]])
	p=  scipy.stats.fisher_exact(cont_table, alternative='two-sided')[1]
	
	s['p-value']= p
	s['Conclusion']= test_conclusion(p=p)
	cols= ['Sub_Group_Survival_Rate', 'Sub_Group_Survivor_Count', 'Sub_Group_Perished_Count', 'Remainder_Group_Suvival_Rate', 'Remainder_Group_Survivor_Count', 'Remainder_Group_Perished_Count', 'p-value', 'Conclusion' ]
	s= s[cols]
	return s



#Create a bar chart of survival rates of each of the Level 1 demographics. Error bars are a 95% confidence interval
#Obtained using a gaussian approximation. Each demographic is compared to all other data NOT contained in the specified demographic
#(excluding NaN values)
#Uncomment the level_1_bar_chart function to include chart in output
	
def level_1_bar_chart():	
	fig, ax= plt.subplots()
	level_1_df= sorted_sub_classes[sorted_sub_classes['Levels']==1]
	level_1_df= level_1_df[['Survival_Rate', 'Half_Confidence_Interval',  'Survival_Rate_of_Rest', 'Half_Confidence_Interval_Rest', 'Normal_Assumption_Valid']]
	demographics= ['Females', '1st Class', 'Children', '2nd Class', 'Adults', '3rd Class', 'Males']
	dem_range= np.arange(len(demographics))*1.5
	bar_values= list(level_1_df['Survival_Rate'])
	rest_bar_values= list(level_1_df['Survival_Rate_of_Rest'])
	bars1=ax.bar(dem_range, bar_values, width=.5, color='y', yerr= list(level_1_df['Half_Confidence_Interval']))
	bars2=ax.bar([x + 0.5 for x in dem_range], rest_bar_values, width=.5, color='r', yerr= list(level_1_df['Half_Confidence_Interval_Rest']))
	ax.set_xticks(dem_range + .5)
	ax.set_xticklabels(demographics)
	ax.set_title('Survival Rates of Main Demographics')
	ax.legend((bars1[0], bars2[0]), ('Demographic of Interest', 'Rest of Passengers'), loc=9)
	ax.set_ylabel('Survival Rate')
	plt.show()
	print level_1_df
	level_1_df.to_csv('Level_1_Table.csv')
	return

#level_1_bar_chart()



"""The following code takes a closer look at various demographics. Some code creates csv files to be included in the project folder. Uncomment any of them to include in output."""

#print sorted_sub_classes
#sorted_sub_classes.to_csv('Sorted_Demographic_Stats.csv')

top_5_survivors= sorted_sub_classes[sorted_sub_classes['Levels']==3][['Survival_Rate', 'Sample_Size', 'Fisher_Test_p-value', 'Fisher_Test_Conclusion']].head(5)
#top_5_survivors.to_csv('Top_5_Survivors.csv')
#print top_5_survivors

bottom_5_survivors= sorted_sub_classes[sorted_sub_classes['Levels']==3][['Survival_Rate', 'Sample_Size', 'Fisher_Test_p-value', 'Fisher_Test_Conclusion']].tail(5).sort_values(by='Survival_Rate')
#print bottom_5_survivors
#bottom_5_survivors.to_csv('Bottom_5_Survivors.csv')

most_significant_dems= sorted_sub_classes[['Survival_Rate', 'Sample_Size', 'Fisher_Test_p-value', 'Fisher_Test_Conclusion']].sort_values(by='Fisher_Test_p-value').head(5)
#print most_significant_dems
#most_significant_dems.to_csv('Most_Significant_Deviations.csv')

#What about men, women, and children?
mwc_general= sorted_sub_classes.loc[['AM', 'AF', 'C']][['Survival_Rate', 'Half_Confidence_Interval']]
#print mwc_general
#mwc_general.to_csv('Men_Women_Children_General.csv')

#Adult Males vs Women and Children as a whole
#print sorted_sub_classes.loc['AM']

#Did adult females make out significantly better than children?
#print stat_sig_between_groups(sex1='female', pclass1='', adult_status1='Adult', sex2='', pclass2='', adult_status2='Child')

#How did female adults compare with female children?
#print stat_sig_between_groups(sex1='female', pclass1='', adult_status1='Adult', sex2='female', pclass2='', adult_status2='Child')


#How do male adults compare to the rest of the population (women and children)?
adult_males_by_class= sorted_sub_classes[(sorted_sub_classes['Levels']==3) & (sorted_sub_classes['Sex']=='male') & (sorted_sub_classes['Adult_Status']=='Adult')]
#print adult_males_by_class


#creating a dataframe to compare adult men to women and children of each class
mwc_rows=[]
for i in range(3):
	x= stat_sig_between_groups(sex1= 'male', pclass1=i+1, adult_status1='Adult', sex2= '', pclass2=i+1, adult_status2='')
	x.index=[i+1]
	mwc_rows.append(x)
mwc_by_class= pd.concat(mwc_rows)
mwc_by_class['Difference_In_Survival_Rates']= mwc_by_class['Remainder_Group_Suvival_Rate'].subtract(mwc_by_class['Sub_Group_Survival_Rate'])
mwc_by_class.columns=['Adult_Male_Survival_Rate', 'Adult_Male_Survivor_Count', \
 'Adult_Male_Perished_Count', 'Women_And_Children_Survival_Rate', \
 'Women_And_Children_Survivor_Count', 'Women_And_Children_Perished_Count', \
 'p-value' ,'Conclusion', 'Difference_In_Survival_Rates']
mwc_by_class= mwc_by_class[['Adult_Male_Survival_Rate', 'Women_And_Children_Survival_Rate', 'Difference_In_Survival_Rates', 'p-value', 'Conclusion']]
#mwc_by_class.to_csv('Men_vs_Women_and_Children_by_Class.csv')
#print mwc_by_class

#Does sex matter for children? (try different ages of adulthood)
#print stat_sig_between_groups(sex1= 'male', pclass1='', adult_status1='Child', sex2= 'female', pclass2='', adult_status2='Child')

#Does class matter for children?
#print sorted_sub_classes[(sorted_sub_classes['Levels']==2) & (sorted_sub_classes['Adult_Status']=='Child') & (sorted_sub_classes['Pclass']!='')]


#about_df()
#about_survived()
#about_age()
#about_Pclass()
#about_sex()



